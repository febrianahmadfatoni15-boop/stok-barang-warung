import 'package:flutter/material.dart';
import 'screens/home_screen.dart';
import 'screens/inventory_screen.dart';
import 'screens/add_item_screen.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Store Inventory System',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        useMaterial3: true,
      ),
      home: const HomeScreen(),
    );
  }
}

// Main HomeScreen Widget Definition
class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // App Bar Section - Top Navigation Bar
      appBar: AppBar(
        title: const Text('Store Inventory System'),
      ),
      
      // Side Navigation Drawer
      drawer: Drawer(
        child: ListView(
          children: [
            // Drawer Header - Menu Title
            const DrawerHeader(
              decoration: BoxDecoration(color: Colors.blue),
              child: Text('Menu', 
                style: TextStyle(color: Colors.white, fontSize: 24)
              ),
            ),
            
            // Navigation Item - Inventory List
            ListTile(
              title: const Text('Inventory List'),
              onTap: () {
                // Navigation Action to Inventory Screen
                Navigator.push(context,
                    MaterialPageRoute(builder: (context) => const InventoryScreen()));
              },
            ),
            
            // Navigation Item - Add New Item
            ListTile(
              title: const Text('Add New Item'),
              onTap: () {
                // Navigation Action to Add Item Screen
                Navigator.push(context,
                    MaterialPageRoute(builder: (context) => const AddItemScreen()));
              },
            ),
          ],
        ),
      ),
      
      // Main Content Area - Welcome Message
      body: const Center(
        child: Text('Welcome to Store Inventory System'),
      ),
    );
  }
}