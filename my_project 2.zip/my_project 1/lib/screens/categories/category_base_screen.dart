import 'package:flutter/material.dart';
import '../../models/product.dart';
import '../../services/storage_service.dart';

class CategoryBaseScreen extends StatefulWidget {
  final String title;
  final IconData icon;
  final List<String> initialItems;

  const CategoryBaseScreen({
    super.key,
    required this.title,
    required this.icon,
    required this.initialItems,
  });

  @override
  State<CategoryBaseScreen> createState() => _CategoryBaseScreenState();
}

class _CategoryBaseScreenState extends State<CategoryBaseScreen> {
  final _storageService = StorageService();
  List<Product> _products = [];

  @override
  void initState() {
    super.initState();
    _loadProducts();
  }

  Future<void> _loadProducts() async {
    final products = await _storageService.getProductsByCategory(widget.title);
    if (products.isEmpty) {
      // Initialize with default items if empty
      for (final item in widget.initialItems) {
        await _storageService.addProduct(
          Product(name: item, category: widget.title),
        );
      }
      products.addAll(await _storageService.getProductsByCategory(widget.title));
    }
    setState(() => _products = products);
  }

  Future<void> _editStock(Product product) async {
    final controller = TextEditingController(text: product.stock.toString());
    return showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Edit Stok ${product.name}'),
        content: TextField(
          controller: controller,
          decoration: const InputDecoration(
            labelText: 'Jumlah Stok',
            border: OutlineInputBorder(),
          ),
          keyboardType: TextInputType.number,
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Batal'),
          ),
          TextButton(
            onPressed: () async {
              final newStock = int.tryParse(controller.text) ?? 0;
              await _storageService.updateProductStock(
                widget.title,
                product.name,
                newStock,
              );
              if (mounted) {
                Navigator.pop(context);
                _loadProducts();
              }
            },
            child: const Text('Simpan'),
          ),
        ],
      ),
    );
  }

  Future<void> _addProduct() async {
    final nameController = TextEditingController();
    final stockController = TextEditingController();
    return showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Tambah Produk Baru'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: nameController,
              decoration: const InputDecoration(
                labelText: 'Nama Produk',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: stockController,
              decoration: const InputDecoration(
                labelText: 'Jumlah Stok',
                border: OutlineInputBorder(),
              ),
              keyboardType: TextInputType.number,
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Batal'),
          ),
          TextButton(
            onPressed: () async {
              final stock = int.tryParse(stockController.text) ?? 0;
              await _storageService.addProduct(
                Product(
                  name: nameController.text,
                  stock: stock,
                  category: widget.title,
                ),
              );
              if (mounted) {
                Navigator.pop(context);
                _loadProducts();
              }
            },
            child: const Text('Simpan'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.title)),
      body: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: _products.length,
        itemBuilder: (context, index) {
          final product = _products[index];
          return Card(
            child: ListTile(
              leading: Icon(widget.icon),
              title: Text(product.name),
              subtitle: Text('Stok: ${product.stock}'),
              trailing: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  IconButton(
                    icon: const Icon(Icons.edit),
                    onPressed: () => _editStock(product),
                  ),
                  IconButton(
                    icon: const Icon(Icons.delete),
                    onPressed: () async {
                      await _storageService.deleteProduct(
                        widget.title,
                        product.name,
                      );
                      _loadProducts();
                    },
                  ),
                ],
              ),
            ),
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _addProduct,
        child: const Icon(Icons.add),
      ),
    );
  }
}