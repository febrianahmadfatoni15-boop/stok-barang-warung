import 'package:flutter/material.dart';
import '../../models/product.dart';
import '../../services/storage_service.dart';

class RokokScreen extends StatefulWidget {
  const RokokScreen({super.key});

  @override
  State<RokokScreen> createState() => _RokokScreenState();
}

class _RokokScreenState extends State<RokokScreen> {
  final StorageService _storage = StorageService();
  List<Product> _products = [];
  List<Product> _filteredProducts = [];
  static const String category = 'Rokok';
  final TextEditingController _searchController = TextEditingController();
  String _searchQuery = '';

  @override
  void initState() {
    super.initState();
    _loadProducts();
    _searchController.addListener(_onSearchChanged);
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  void _onSearchChanged() {
    setState(() {
      _searchQuery = _searchController.text;
      _filterProducts();
    });
  }

  void _filterProducts() {
    if (_searchQuery.isEmpty) {
      _filteredProducts = List.from(_products);
    } else {
      _filteredProducts = _products
          .where((p) => p.name.toLowerCase().contains(_searchQuery.toLowerCase()))
          .toList();
    }
  }

  Future<void> _loadProducts() async {
    final products = await _storage.getProductsByCategory(category);
    if (products.isEmpty) {
      final defaultItems = ['Sampoerna', 'Marlboro', 'Surya'];
      for (final item in defaultItems) {
        await _storage.addProduct(Product(name: item, category: category));
      }
      _products = await _storage.getProductsByCategory(category);
    } else {
      _products = products;
    }
    _filterProducts();
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Rokok'),
        actions: [
          IconButton(
            icon: const Icon(Icons.search),
            onPressed: () {
              showDialog(
                context: context,
                builder: (context) => AlertDialog(
                  title: const Text('Cari Produk'),
                  content: TextField(
                    controller: _searchController,
                    autofocus: true,
                    decoration: const InputDecoration(
                      hintText: 'Cari produk...',
                      border: OutlineInputBorder(),
                    ),
                  ),
                  actions: [
                    TextButton(
                      onPressed: () {
                        _searchController.clear();
                        Navigator.pop(context);
                      },
                      child: const Text('Tutup'),
                    ),
                  ],
                ),
              );
            },
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: TextField(
              controller: _searchController,
              decoration: const InputDecoration(
                labelText: 'Cari produk...',
                prefixIcon: Icon(Icons.search),
                border: OutlineInputBorder(),
              ),
            ),
          ),
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: _filteredProducts.length,
              itemBuilder: (context, index) {
                final product = _filteredProducts[index];
                return Card(
                  elevation: 4,
                  child: ListTile(
                    title: Text(product.name),
                    subtitle: Text('Stok: ${product.stock}'),
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        IconButton(
                          icon: const Icon(Icons.edit),
                          onPressed: () => _editStock(product),
                        ),
                        IconButton(
                          icon: const Icon(Icons.delete),
                          onPressed: () => _deleteProduct(product),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _addNewProduct,
        child: const Icon(Icons.add),
      ),
    );
  }

  Future<void> _editStock(Product product) async {
    final controller = TextEditingController(text: product.stock.toString());
    await showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Edit Stok ${product.name}'),
        content: TextField(
          controller: controller,
          decoration: const InputDecoration(
            labelText: 'Jumlah Stok',
            border: OutlineInputBorder(),
          ),
          keyboardType: TextInputType.number,
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Batal'),
          ),
          TextButton(
            onPressed: () async {
              final newStock = int.tryParse(controller.text) ?? 0;
              await _storage.updateProductStock(category, product.name, newStock);
              Navigator.pop(context);
              _loadProducts();
            },
            child: const Text('Simpan'),
          ),
        ],
      ),
    );
  }

  Future<void> _addNewProduct() async {
    final nameController = TextEditingController();
    final stockController = TextEditingController();
    await showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Tambah Produk Baru'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: nameController,
              decoration: const InputDecoration(
                labelText: 'Nama Produk',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: stockController,
              decoration: const InputDecoration(
                labelText: 'Jumlah Stok',
                border: OutlineInputBorder(),
              ),
              keyboardType: TextInputType.number,
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Batal'),
          ),
          TextButton(
            onPressed: () async {
              if (nameController.text.isNotEmpty) {
                final stock = int.tryParse(stockController.text) ?? 0;
                await _storage.addProduct(
                  Product(
                    name: nameController.text,
                    stock: stock,
                    category: category,
                  ),
                );
                Navigator.pop(context);
                _loadProducts();
              }
            },
            child: const Text('Simpan'),
          ),
        ],
      ),
    );
  }

  Future<void> _deleteProduct(Product product) async {
    await showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Hapus Produk'),
        content: Text('Hapus ${product.name}?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Batal'),
          ),
          TextButton(
            onPressed: () async {
              await _storage.deleteProduct(category, product.name);
              Navigator.pop(context);
              _loadProducts();
            },
            child: const Text('Hapus'),
          ),
        ],
      ),
    );
  }
}