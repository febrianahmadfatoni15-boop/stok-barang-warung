import 'package:flutter/material.dart';

class CategoryDetailScreen extends StatelessWidget {
  final String title;
  const CategoryDetailScreen({super.key, required this.title});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(title),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Daftar $title',
              style: const TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 16),
            // Add your inventory list here
            Expanded(
              child: ListView.builder(
                itemCount: 10, // Replace with actual data
                itemBuilder: (context, index) {
                  return Card(
                    child: ListTile(
                      title: Text('Item ${index + 1}'),
                      subtitle: Text('Stok: ${index * 5}'),
                      trailing: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          IconButton(
                            icon: const Icon(Icons.edit),
                            onPressed: () {
                              // Add edit functionality
                            },
                          ),
                          IconButton(
                            icon: const Icon(Icons.delete),
                            onPressed: () {
                              // Add delete functionality
                            },
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          // Add new item functionality
        },
        child: const Icon(Icons.add),
      ),
    );
  }
}