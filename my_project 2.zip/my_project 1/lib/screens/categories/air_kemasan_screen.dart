import 'package:flutter/material.dart';
import '../../models/product.dart';
import '../../services/storage_service.dart';

class AirKemasanScreen extends StatefulWidget {
  const AirKemasanScreen({super.key});

  @override
  State<AirKemasanScreen> createState() => _AirKemasanScreenState();
}

class _AirKemasanScreenState extends State<AirKemasanScreen> {
  final StorageService _storage = StorageService();
  List<Product> _products = [];
  List<Product> _filteredProducts = []; // Add this line
  final TextEditingController _searchController = TextEditingController(); // Add this line
  final String category = 'Air Kemasan';

  @override
  void initState() {
    super.initState();
    _loadProducts();
  }

  @override
  void dispose() {
    _searchController.dispose(); // Add this line
    super.dispose();
  }

  Future<void> _loadProducts() async {
    final products = await _storage.getProductsByCategory(category);
    if (products.isEmpty) {
      final defaultItems = ['Aqua 600ml', 'Le Minerale 600ml', 'Club 330ml', 'Vit 1.5L', 'Prima 600ml'];
      for (final item in defaultItems) {
        await _storage.addProduct(Product(name: item, category: category));
      }
      _products = await _storage.getProductsByCategory(category);
    } else {
      _products = products;
    }
    _filteredProducts = _products; // Add this line
    setState(() {});
  }

  void _filterProducts(String query) {  // Add this method
    setState(() {
      _filteredProducts = _products
          .where((product) =>
              product.name.toLowerCase().contains(query.toLowerCase()))
          .toList();
    });
  }

  Future<void> _editStock(Product product) async {
    final controller = TextEditingController(text: product.stock.toString());
    await showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        title: Text('Edit Stok ${product.name}'),
        content: TextField(
          controller: controller,
          decoration: const InputDecoration(
            labelText: 'Jumlah Stok',
            border: OutlineInputBorder(),
          ),
          keyboardType: TextInputType.number,
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Batal'),
          ),
          TextButton(
            onPressed: () async {
              try {
                final newStock = int.tryParse(controller.text) ?? 0;
                await _storage.updateProductStock(
                  category,
                  product.name,
                  newStock,
                );
                if (mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Stok berhasil diperbarui')),
                  );
                  Navigator.pop(context);
                  _loadProducts();
                }
              } catch (e) {
                if (mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Gagal memperbarui stok')),
                  );
                }
              }
            },
            child: const Text('Simpan'),
          ),
        ],
      ),
    );
  }

  Future<void> _addNewProduct() async {
    final nameController = TextEditingController();
    final stockController = TextEditingController();

    await showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        title: const Text('Tambah Produk Baru'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: nameController,
              decoration: const InputDecoration(
                labelText: 'Nama Produk',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: stockController,
              decoration: const InputDecoration(
                labelText: 'Jumlah Stok',
                border: OutlineInputBorder(),
              ),
              keyboardType: TextInputType.number,
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Batal'),
          ),
          TextButton(
            onPressed: () async {
              if (nameController.text.isNotEmpty) {
                try {
                  final stock = int.tryParse(stockController.text) ?? 0;
                  await _storage.addProduct(
                    Product(
                      name: nameController.text,
                      stock: stock,
                      category: category,
                    ),
                  );
                  if (mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Produk berhasil ditambahkan')),
                    );
                    Navigator.pop(context);
                    _loadProducts();
                  }
                } catch (e) {
                  if (mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Gagal menambahkan produk')),
                    );
                  }
                }
              }
            },
            child: const Text('Simpan'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Air Kemasan')),
      body: Column(  // Changed from ListView.builder to Column
        children: [
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: TextField(
              controller: _searchController,
              decoration: InputDecoration(
                labelText: 'Cari Air Kemasan',
                hintText: 'Masukkan nama produk...',
                prefixIcon: const Icon(Icons.search),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
                suffixIcon: _searchController.text.isNotEmpty
                    ? IconButton(
                        icon: const Icon(Icons.clear),
                        onPressed: () {
                          _searchController.clear();
                          _filterProducts('');
                        },
                      )
                    : null,
              ),
              onChanged: _filterProducts,
            ),
          ),
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: _filteredProducts.length,  // Changed from _products to _filteredProducts
              itemBuilder: (context, index) {
                final product = _filteredProducts[index];  // Changed from _products to _filteredProducts
                return Card(
                  elevation: 4,
                  margin: const EdgeInsets.symmetric(vertical: 8),
                  child: ListTile(
                    leading: const Icon(Icons.water),  // Add this line
                    title: Text(product.name),
                    subtitle: Text('Stok: ${product.stock}'),
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        IconButton(
                          icon: const Icon(Icons.edit),
                          onPressed: () => _editStock(product),
                        ),
                        IconButton(
                          icon: const Icon(Icons.delete),
                          onPressed: () => _deleteProduct(product),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _addNewProduct,
        child: const Icon(Icons.add),
      ),
    );
  }

  void _deleteProduct(Product product) async {
    await showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Hapus Produk'),
        content: Text('Hapus ${product.name}?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Batal'),
          ),
          TextButton(
            onPressed: () async {
              await _storage.deleteProduct(category, product.name);
              Navigator.pop(context);
              _loadProducts();
            },
            child: const Text('Hapus'),
          ),
        ],
      ),
    );
  }
}