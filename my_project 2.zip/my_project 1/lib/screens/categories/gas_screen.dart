import 'package:flutter/material.dart';
import '../../models/product.dart';
import '../../services/storage_service.dart';

class GasScreen extends StatefulWidget {
  const GasScreen({super.key});

  @override
  State<GasScreen> createState() => _GasScreenState();
}

class _GasScreenState extends State<GasScreen> {
  final StorageService _storage = StorageService();
  final TextEditingController _searchController = TextEditingController();
  List<Product> _products = [];
  List<Product> _filteredProducts = [];
  final String category = 'Gas';

  @override
  void initState() {
    super.initState();
    _loadProducts();
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _loadProducts() async {
    final products = await _storage.getProductsByCategory(category);
    if (products.isEmpty) {
      final defaultItems = ['Gas 3kg', 'Gas 12kg'];
      for (final item in defaultItems) {
        await _storage.addProduct(Product(name: item, category: category));
      }
      _products = await _storage.getProductsByCategory(category);
    } else {
      _products = products;
    }
    _filteredProducts = _products;
    setState(() {});
  }

  void _filterProducts(String query) {
    setState(() {
      _filteredProducts = _products
          .where((product) =>
              product.name.toLowerCase().contains(query.toLowerCase()))
          .toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Gas')),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: TextField(
              controller: _searchController,
              decoration: InputDecoration(
                labelText: 'Cari Gas',
                hintText: 'Masukkan jenis gas...',
                prefixIcon: const Icon(Icons.search),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
                suffixIcon: _searchController.text.isNotEmpty
                    ? IconButton(
                        icon: const Icon(Icons.clear),
                        onPressed: () {
                          _searchController.clear();
                          _filterProducts('');
                        },
                      )
                    : null,
              ),
              onChanged: _filterProducts,
            ),
          ),
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: _filteredProducts.length,
              itemBuilder: (context, index) {
                final product = _filteredProducts[index];
                return Card(
                  elevation: 4,
                  margin: const EdgeInsets.symmetric(vertical: 8),
                  child: ListTile(
                    leading: const Icon(Icons.local_fire_department),
                    title: Text(product.name),
                    subtitle: Text('Stok: ${product.stock}'),
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        IconButton(
                          icon: const Icon(Icons.edit),
                          onPressed: () => _editStock(product),
                        ),
                        IconButton(
                          icon: const Icon(Icons.delete),
                          onPressed: () => _deleteProduct(product),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _addNewProduct,
        child: const Icon(Icons.add),
      ),
    );
  }

  void _editStock(Product product) async {
    final controller = TextEditingController(text: product.stock.toString());
    final result = await showDialog<int>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Edit Stok - ${product.name}'),
        content: TextField(
          controller: controller,
          keyboardType: TextInputType.number,
          decoration: const InputDecoration(labelText: 'Stok'),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Batal'),
          ),
          TextButton(
            onPressed: () {
              final stokBaru = int.tryParse(controller.text) ?? product.stock;
              Navigator.pop(context, stokBaru);
            },
            child: const Text('Simpan'),
          ),
        ],
      ),
    );
    if (result != null) {
      product.stock = result;
      await _storage.updateProductStock(product.name, product.category, product.stock);
      await _loadProducts();
    }
  }

  void _deleteProduct(Product product) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Konfirmasi Hapus'),
        content: Text('Yakin ingin menghapus produk "${product.name}"?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Batal'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Hapus', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
    if (confirm == true) {
      await _storage.deleteProduct(product.name, product.category);
      await _loadProducts();
    }
  }

  void _addNewProduct() async {
    final nameController = TextEditingController();
    final stockController = TextEditingController(text: '0');
    final result = await showDialog<Product>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Tambah Produk Gas'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: nameController,
              decoration: const InputDecoration(labelText: 'Nama Produk'),
            ),
            TextField(
              controller: stockController,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(labelText: 'Stok'),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Batal'),
          ),
          TextButton(
            onPressed: () {
              final name = nameController.text.trim();
              final stock = int.tryParse(stockController.text) ?? 0;
              if (name.isNotEmpty) {
                Navigator.pop(
                  context,
                  Product(name: name, stock: stock, category: category),
                );
              }
            },
            child: const Text('Tambah'),
          ),
        ],
      ),
    );
    if (result != null) {
      await _storage.addProduct(result);
      await _loadProducts();
    }
  }
}