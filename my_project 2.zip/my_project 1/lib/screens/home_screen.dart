import 'package:flutter/material.dart';
import 'categories/category_detail_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final List<Map<String, dynamic>> categories = [
      {'title': 'Makanan Ringan', 'icon': Icons.fastfood},
      {'title': 'Minuman', 'icon': Icons.local_drink},
      {'title': 'Sembako', 'icon': Icons.shopping_basket},
      {'title': 'Rokok', 'icon': Icons.smoking_rooms},
      {'title': 'Bumbu Dapur', 'icon': Icons.restaurant},
      {'title': 'Perlengkapan Mandi', 'icon': Icons.bathtub},
      {'title': 'Gas', 'icon': Icons.local_fire_department},
      {'title': 'Galon', 'icon': Icons.water},
      {'title': 'Air Kemasan', 'icon': Icons.local_drink},
    ];

    return Scaffold(
      appBar: AppBar(
        title: const Text('Sistem Stok Barang Warung Ocit'),
        actions: [
          IconButton(
            icon: const Icon(Icons.search),
            onPressed: () async {
              await showDialog(
                context: context,
                builder: (context) {
                  TextEditingController searchController = TextEditingController();
                  List<Map<String, dynamic>> filtered = List.from(categories);
                  return StatefulBuilder(
                    builder: (context, setState) => AlertDialog(
                      title: const Text('Cari Kategori'),
                      content: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          TextField(
                            controller: searchController,
                            autofocus: true,
                            decoration: const InputDecoration(
                              hintText: 'Cari kategori...',
                              border: OutlineInputBorder(),
                            ),
                            onChanged: (value) {
                              setState(() {
                                filtered = categories
                                    .where((cat) => cat['title']
                                        .toLowerCase()
                                        .contains(value.toLowerCase()))
                                    .toList();
                              });
                            },
                          ),
                          const SizedBox(height: 16),
                          SizedBox(
                            height: 200,
                            width: 300,
                            child: filtered.isEmpty
                                ? const Center(child: Text('Tidak ditemukan'))
                                : ListView.builder(
                                    itemCount: filtered.length,
                                    itemBuilder: (context, idx) {
                                      final cat = filtered[idx];
                                      return ListTile(
                                        leading: Icon(cat['icon']),
                                        title: Text(cat['title']),
                                        onTap: () {
                                          Navigator.pop(context);
                                          Navigator.push(
                                            context,
                                            MaterialPageRoute(
                                              builder: (context) => CategoryDetailScreen(title: cat['title']),
                                            ),
                                          );
                                        },
                                      );
                                    },
                                  ),
                          ),
                        ],
                      ),
                      actions: [
                        TextButton(
                          onPressed: () => Navigator.pop(context),
                          child: const Text('Tutup'),
                        ),
                      ],
                    ),
                  );
                },
              );
            },
          ),
        ],
      ),
      body: GridView.count(
        padding: const EdgeInsets.all(16),
        crossAxisCount: 2,
        mainAxisSpacing: 16,
        crossAxisSpacing: 16,
        children: categories
            .map((cat) => CategoryCard(title: cat['title'], icon: cat['icon']))
            .toList(),
      ),
    );
  }
}

class CategoryCard extends StatelessWidget {
  final String title;
  final IconData icon;

  const CategoryCard({super.key, required this.title, required this.icon});

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 4,
      child: InkWell(
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => CategoryDetailScreen(title: title),
            ),
          );
        },
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, size: 48, color: Theme.of(context).primaryColor),
            const SizedBox(height: 8),
            Text(
              title,
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 16),
            ),
          ],
        ),
      ),
    );
  }
}