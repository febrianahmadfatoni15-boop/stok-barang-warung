import 'package:flutter/material.dart';
import '../login_screen.dart';
import '../models/product.dart';
import '../services/storage_service.dart';
import 'makanan_ringan_screen.dart';
import 'category_detail_screen.dart';
import 'categories/minuman_screen.dart';
import 'categories/sembako_screen.dart';
import 'categories/rokok_screen.dart';
import 'categories/galon_screen.dart';
import 'categories/gas_screen.dart';
import 'categories/bumbu_dapur_screen.dart';
import 'categories/perlengkapan_mandi_screen.dart';
import 'categories/air_kemasan_screen.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  final StorageService _storage = StorageService();
  final TextEditingController _searchController = TextEditingController();
  List<Product> _allProducts = [];
  List<Product> _filteredProducts = []; // Tambahkan ini
  bool _isSearching = false;

  // Move categories list to be a class field
  final List<Map<String, dynamic>> categories = [
    {
      'name': 'Makanan Ringan',
      'icon': Icons.cookie,
      'items': ['Chitato', 'Lay\'s', 'Qtela']
    },
    {
      'name': 'Minuman',
      'icon': Icons.local_drink,
      'items': ['Coca Cola', 'Sprite', 'Fanta']
    },
    {
      'name': 'Sembako',
      'icon': Icons.shopping_bag,
      'items': ['Beras', 'Minyak Goreng', 'Gula']
    },
    {
      'name': 'Rokok',
      'icon': Icons.smoking_rooms,
      'items': ['Sampoerna', 'Marlboro', 'Surya']
    },
    {
      'name': 'Bumbu Dapur',
      'icon': Icons.restaurant,
      'items': ['Garam', 'Merica', 'Ketumbar']
    },
    {
      'name': 'Perlengkapan Mandi',
      'icon': Icons.bathroom,
      'items': ['Sabun', 'Shampoo', 'Sikat Gigi']
    },
    {
      'name': 'Gas',
      'icon': Icons.local_fire_department,
      'items': ['Gas 3kg', 'Gas 12kg']
    },
    {
      'name': 'Galon',
      'icon': Icons.water_drop,
      'items': ['Aqua', 'Club', 'Vit']
    },
    {
      'name': 'Air Kemasan',
      'icon': Icons.water,
      'items': ['Aqua 600ml', 'Le Minerale', 'Club']
    },
  ];

  @override
  void initState() {
    super.initState();
    _loadAllProducts();
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _loadAllProducts() async {
    _allProducts = await _storage.loadProducts();
    setState(() {});
  }

  void _filterProducts(String query) {
    if (query.isEmpty) {
      setState(() {
        _isSearching = false;
        _filteredProducts = [];
      });
      return;
    }

    // Cari dari StorageService
    final storageResults = _allProducts
        .where((product) =>
            product.name.toLowerCase().contains(query.toLowerCase()))
        .toList();

    // Cari dari kategori (label)
    final categoryResults = <Product>[];
    for (var cat in categories) {
      for (var item in cat['items'] as List<String>) {
        if (item.toLowerCase().contains(query.toLowerCase())) {
          categoryResults.add(Product(
            name: item,
            stock: 0,
            category: cat['name'],
          ));
        }
      }
    }

    // Gabungkan dan hilangkan duplikat berdasarkan nama produk
    final allResults = [
      ...storageResults,
      ...categoryResults.where((catProd) =>
          !storageResults.any((prod) => prod.name == catProd.name))
    ];

    setState(() {
      _isSearching = true;
      _filteredProducts = allResults;
    });
  }

  IconData _getCategoryIcon(String category) {
    final categoryData = categories.firstWhere(
      (cat) => cat['name'] == category,
      orElse: () => {'icon': Icons.category},
    );
    return categoryData['icon'] ?? Icons.category;
  }

  Future<void> _showLogoutDialog() async {
    return showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Logout'),
        content: const Text('Apakah Anda yakin ingin keluar?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Batal'),
          ),
          TextButton(
            onPressed: () {
              Navigator.pushAndRemoveUntil(
                context,
                MaterialPageRoute(builder: (context) => const LoginScreen()),
                (route) => false,
              );
            },
            child: const Text('Logout'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: _isSearching
            ? TextField(
                controller: _searchController,
                decoration: InputDecoration(
                  hintText: 'Cari produk...',
                  border: InputBorder.none,
                  suffixIcon: IconButton(
                    icon: const Icon(Icons.clear),
                    onPressed: () {
                      setState(() {
                        _searchController.clear();
                        _isSearching = false;
                      });
                    },
                  ),
                ),
                onChanged: _filterProducts, // Changed from onSubmitted to onChanged
                autofocus: true, // Add autofocus
              )
            : const Text('Sistem Stok Barang Warung Ocit'),
        actions: [
          IconButton(
            icon: Icon(_isSearching ? Icons.cancel : Icons.search),
            onPressed: () {
              setState(() {
                _isSearching = !_isSearching;
                if (!_isSearching) {
                  _searchController.clear();
                }
              });
            },
          ),
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: _showLogoutDialog,
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: _isSearching
            ? (_filteredProducts.isEmpty
                ? const Center(child: Text('Produk tidak ditemukan.'))
                : ListView.builder(
                    itemCount: _filteredProducts.length,
                    itemBuilder: (context, index) {
                      final product = _filteredProducts[index];
                      return Card(
                        child: ListTile(
                          title: Text(product.name),
                          subtitle: Text(
                            '${product.category}\nStok: ${product.stock}',
                            style: const TextStyle(height: 1.2),
                          ),
                          leading: Icon(
                            _getCategoryIcon(product.category),
                            color: Theme.of(context).primaryColor,
                          ),
                          onTap: () {
                            _navigateToCategory(product.category);
                          },
                        ),
                      );
                    },
                  ))
            : GridView.builder(
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  crossAxisSpacing: 16,
                  mainAxisSpacing: 16,
                  childAspectRatio: 1.5,
                ),
                itemCount: categories.length,
                itemBuilder: (context, index) {
                  return Card(
                    elevation: 4,
                    child: InkWell(
                      onTap: () {
                        switch (categories[index]['name']) {
                          case 'Makanan Ringan':
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => const MakananRinganScreen()),
                            );
                            break;
                          case 'Minuman':
                            Navigator.push(
                              context,
                              MaterialPageRoute(builder: (context) => const MinumanScreen()),
                            );
                            break;
                          case 'Sembako':
                            Navigator.push(
                              context,
                              MaterialPageRoute(builder: (context) => const SembakoScreen()),
                            );
                            break;
                          case 'Rokok':
                            Navigator.push(
                              context,
                              MaterialPageRoute(builder: (context) => const RokokScreen()),
                            );
                            break;
                          case 'Galon':
                            Navigator.push(
                              context,
                              MaterialPageRoute(builder: (context) => GalonScreen()),
                            );
                            break;
                          case 'Gas':
                            Navigator.push(
                              context,
                              MaterialPageRoute(builder: (context) => GasScreen()),
                            );
                            break;
                          case 'Bumbu Dapur':
                            Navigator.push(
                              context,
                              MaterialPageRoute(builder: (context) => const BumbuDapurScreen()),
                            );
                            break;
                          case 'Perlengkapan Mandi':
                            Navigator.push(
                              context,
                              MaterialPageRoute(builder: (context) => const PerlengkapanMandiScreen()),
                            );
                            break;
                          case 'Air Kemasan':
                            Navigator.push(
                              context,
                              MaterialPageRoute(builder: (context) => const AirKemasanScreen()),
                            );
                            break;
                          // Add cases for other categories...
                          default:
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => CategoryDetailScreen(
                                  title: categories[index]['name'],
                                  items:
                                      List<String>.from(categories[index]['items'] ?? []),
                                  icon: categories[index]['icon'],
                                ),
                              ),
                            );
                        }
                      },
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(
                            categories[index]['icon'],
                            size: 40,
                            color: Theme.of(context).primaryColor,
                          ),
                          const SizedBox(height: 8),
                          Text(
                            categories[index]['name'],
                            textAlign: TextAlign.center,
                            style: const TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
      ),
    );
  }

  void _navigateToCategory(String category) {
    switch (category) {
      case 'Makanan Ringan':
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => const MakananRinganScreen()),
        );
        break;
      case 'Minuman':
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => const MinumanScreen()),
        );
        break;
      case 'Sembako':
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => const SembakoScreen()),
        );
        break;
      case 'Rokok':
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => const RokokScreen()),
        );
        break;
      case 'Galon':
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => const GalonScreen()),
        );
        break;
      case 'Gas':
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => const GasScreen()),
        );
        break;
      case 'Bumbu Dapur':
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => const BumbuDapurScreen()),
        );
        break;
      case 'Perlengkapan Mandi':
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => const PerlengkapanMandiScreen()),
        );
        break;
      case 'Air Kemasan':
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => const AirKemasanScreen()),
        );
        break;
    }
  }
}