class Product {
  final String name;
  int stock;
  final String category;

  Product({
    required this.name,
    this.stock = 0,
    required this.category,
  });

  Map<String, dynamic> toJson() => {
    'name': name,
    'stock': stock,
    'category': category,
  };

  factory Product.fromJson(Map<String, dynamic> json) => Product(
    name: json['name'],
    stock: json['stock'],
    category: json['category'],
  );
}