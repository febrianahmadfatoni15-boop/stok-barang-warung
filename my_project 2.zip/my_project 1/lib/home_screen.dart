import 'package:flutter/material.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Sistem Stok Barang Warung Ocit'),
      ),
      body: GridView.count(
        padding: const EdgeInsets.all(16),
        crossAxisCount: 2,
        mainAxisSpacing: 16,
        crossAxisSpacing: 16,
        children: const [
          CategoryCard(title: 'Makanan Ringan', icon: Icons.fastfood),
          CategoryCard(title: 'Minuman', icon: Icons.local_drink),
          CategoryCard(title: 'Sembako', icon: Icons.shopping_basket),
          CategoryCard(title: 'Rokok', icon: Icons.smoking_rooms),
          CategoryCard(title: 'Bumbu Dapur', icon: Icons.restaurant),
          CategoryCard(title: 'Perlengkapan Mandi', icon: Icons.bathtub),
          CategoryCard(title: 'Gas', icon: Icons.local_fire_department),
          CategoryCard(title: 'Galon', icon: Icons.water),
          CategoryCard(title: 'Air Kemasan', icon: Icons.local_drink),
        ],
      ),
    );
  }
}

class CategoryCard extends StatelessWidget {
  final String title;
  final IconData icon;

  const CategoryCard({
    super.key,
    required this.title,
    required this.icon,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 4,
      child: InkWell(
        onTap: () {
          // TODO: Navigate to category detail
        },
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, size: 48, color: Theme.of(context).primaryColor),
            const SizedBox(height: 8),
            Text(
              title,
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 16),
            ),
          ],
        ),
      ),
    );
  }
}