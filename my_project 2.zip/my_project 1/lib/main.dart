import 'package:flutter/material.dart';
import 'login_screen.dart';
import 'models/product.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Sistem Stok Barang Warung Ocit',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.blue,
        useMaterial3: true,
      ),
      home: const LoginScreen(),
    );
  }
}

class ProductPage extends StatefulWidget {
  @override
  State<ProductPage> createState() => _ProductPageState();
}

class _ProductPageState extends State<ProductPage> {
  List<Product> products = [
    Product(name: 'Produk A', stock: 10, category: 'Kategori 1'),
    Product(name: 'Produk B', stock: 5, category: 'Kategori 2'),
  ];

  void _addProduct() async {
    final result = await showDialog<Product>(
      context: context,
      builder: (context) => ProductDialog(),
    );
    if (result != null) {
      setState(() {
        products.add(result);
      });
    }
  }

  void _editProduct(int index) async {
    final result = await showDialog<Product>(
      context: context,
      builder: (context) => ProductDialog(product: products[index]),
    );
    if (result != null) {
      setState(() {
        products[index] = result;
      });
    }
  }

  void _deleteProduct(int index) {
    setState(() {
      products.removeAt(index);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Daftar Produk'),
        actions: [
          IconButton(
            icon: Icon(Icons.search),
            onPressed: () {
              showSearch(
                context: context,
                delegate: ProductSearchDelegate(products),
              );
            },
          ),
        ],
      ),
      body: ListView.builder(
        itemCount: products.length,
        itemBuilder: (context, index) {
          final p = products[index];
          return ListTile(
            title: Text(p.name),
            subtitle: Text('Stok: ${p.stock} | Kategori: ${p.category}'),
            trailing: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                IconButton(
                  icon: Icon(Icons.edit),
                  onPressed: () => _editProduct(index),
                ),
                IconButton(
                  icon: Icon(Icons.delete),
                  onPressed: () => _deleteProduct(index),
                ),
              ],
            ),
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _addProduct,
        child: Icon(Icons.add),
      ),
    );
  }
}

class ProductDialog extends StatefulWidget {
  final Product? product;
  ProductDialog({this.product});

  @override
  State<ProductDialog> createState() => _ProductDialogState();
}

class _ProductDialogState extends State<ProductDialog> {
  late TextEditingController nameController;
  late TextEditingController stockController;
  late TextEditingController categoryController;

  @override
  void initState() {
    super.initState();
    nameController = TextEditingController(text: widget.product?.name ?? '');
    stockController = TextEditingController(text: widget.product?.stock.toString() ?? '0');
    categoryController = TextEditingController(text: widget.product?.category ?? '');
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(widget.product == null ? 'Tambah Produk' : 'Edit Produk'),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          TextField(
            controller: nameController,
            decoration: InputDecoration(labelText: 'Nama Produk'),
          ),
          TextField(
            controller: stockController,
            decoration: InputDecoration(labelText: 'Stok'),
            keyboardType: TextInputType.number,
          ),
          TextField(
            controller: categoryController,
            decoration: InputDecoration(labelText: 'Kategori'),
          ),
        ],
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: Text('Batal'),
        ),
        TextButton(
          onPressed: () {
            final name = nameController.text;
            final stock = int.tryParse(stockController.text) ?? 0;
            final category = categoryController.text;
            if (name.isNotEmpty && category.isNotEmpty) {
              Navigator.pop(
                context,
                Product(name: name, stock: stock, category: category),
              );
            }
          },
          child: Text(widget.product == null ? 'Tambah' : 'Simpan'),
        ),
      ],
    );
  }
}

class ProductSearchDelegate extends SearchDelegate<Product?> {
  final List<Product> products;

  ProductSearchDelegate(this.products);

  @override
  List<Widget>? buildActions(BuildContext context) {
    return [
      IconButton(
        icon: Icon(Icons.clear),
        onPressed: () {
          query = '';
        },
      ),
    ];
  }

  @override
  Widget? buildLeading(BuildContext context) {
    return IconButton(
      icon: Icon(Icons.arrow_back),
      onPressed: () {
        close(context, null);
      },
    );
  }

  @override
  Widget buildResults(BuildContext context) {
    final results = products
        .where((p) =>
            p.name.toLowerCase().contains(query.toLowerCase()) ||
            p.category.toLowerCase().contains(query.toLowerCase()))
        .toList();

    if (results.isEmpty) {
      return Center(child: Text('Tidak ada produk ditemukan.'));
    }

    return ListView.builder(
      itemCount: results.length,
      itemBuilder: (context, index) {
        final p = results[index];
        return ListTile(
          title: Text(p.name),
          subtitle: Text('Stok: ${p.stock} | Kategori: ${p.category}'),
        );
      },
    );
  }

  @override
  Widget buildSuggestions(BuildContext context) {
    final suggestions = products
        .where((p) =>
            p.name.toLowerCase().contains(query.toLowerCase()) ||
            p.category.toLowerCase().contains(query.toLowerCase()))
        .toList();

    return ListView.builder(
      itemCount: suggestions.length,
      itemBuilder: (context, index) {
        final p = suggestions[index];
        return ListTile(
          title: Text(p.name),
          subtitle: Text('Stok: ${p.stock} | Kategori: ${p.category}'),
          onTap: () {
            query = p.name;
            showResults(context);
          },
        );
      },
    );
  }
}
