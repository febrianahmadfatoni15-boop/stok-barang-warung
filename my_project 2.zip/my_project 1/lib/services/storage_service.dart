import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/product.dart';

class StorageService {
  static const String _key = 'products';
  
  Future<void> saveProducts(List<Product> products) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final productsJson = products.map((p) => p.toJson()).toList();
      await prefs.setString(_key, jsonEncode(productsJson));
    } catch (e) {
      print('Error saving products: $e');
    }
  }

  Future<List<Product>> loadProducts() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final productsJson = prefs.getString(_key);
      if (productsJson == null) return [];
      
      final List<dynamic> decoded = jsonDecode(productsJson);
      return decoded.map((json) => Product.fromJson(json)).toList();
    } catch (e) {
      print('Error loading products: $e');
      return [];
    }
  }

  Future<List<Product>> getProductsByCategory(String category) async {
    final products = await loadProducts();
    return products.where((p) => p.category == category).toList();
  }

  Future<void> updateProductStock(String category, String name, int newStock) async {
    try {
      final products = await loadProducts();
      final index = products.indexWhere((p) => p.category == category && p.name == name);
      if (index != -1) {
        products[index].stock = newStock;
        await saveProducts(products);
      }
    } catch (e) {
      print('Error updating stock: $e');
    }
  }

  Future<void> addProduct(Product product) async {
    try {
      final products = await loadProducts();
      products.add(product);
      await saveProducts(products);
    } catch (e) {
      print('Error adding product: $e');
    }
  }

  Future<void> deleteProduct(String category, String name) async {
    try {
      final products = await loadProducts();
      products.removeWhere((p) => p.category == category && p.name == name);
      await saveProducts(products);
    } catch (e) {
      print('Error deleting product: $e');
    }
  }
}